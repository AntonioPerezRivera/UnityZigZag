﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class MovimientoPoia : MonoBehaviour {

	public Text miTexto;

	public void poia(){
		miTexto.text = "LMAO";
	}
}
